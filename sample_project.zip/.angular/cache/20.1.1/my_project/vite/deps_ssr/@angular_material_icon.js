import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-BVX5IA73.js";
import "./chunk-XOSJ67K4.js";
import "./chunk-KJJ3NM7W.js";
import "./chunk-XIMC4YRX.js";
import "./chunk-526RMYH5.js";
import "./chunk-KFZDAVZB.js";
import "./chunk-55FRCD3A.js";
import "./chunk-SOVSN7UZ.js";
import "./chunk-6DU2HRTW.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
