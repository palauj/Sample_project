import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LobWizard } from './lob-wizard';

describe('LobWizard', () => {
  let component: LobWizard;
  let fixture: ComponentFixture<LobWizard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LobWizard]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LobWizard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
