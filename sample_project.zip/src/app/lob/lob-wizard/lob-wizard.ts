import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  FormArray,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';

import { MatStepperModule } from '@angular/material/stepper';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';

@Component({
  selector: 'app-lob-wizard',
  standalone: true,
  templateUrl: './lob-wizard.html',
  styleUrl: './lob-wizard.scss',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatStepperModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatIconModule,
    MatTabsModule,
  ],
})
export class LobWizard {
  lobForm!: FormGroup;
  services = ['SMS-OTP', 'SMS-NOTP', 'EMAIL-OTP', 'EMAIL-NOTP', 'WHATSAPP-TEMPLATE'];
  selectedServices: string[] = [];
  mockProviders = ['Provider A', 'Provider B', 'Provider C'];
  serviceProvidersData: { [key: string]: FormArray } = {};

  constructor(private fb: FormBuilder) {
    this.lobForm = this.fb.group({
      stepOne: this.fb.group({
        lobName: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
      }),
      stepTwo: this.fb.group({
        services: [[], Validators.required],
      }),
    });
  }

  ngOnInit() {
    this.stepTwoGroup.get('services')?.valueChanges.subscribe((services: string[]) => {
      this.selectedServices = services || [];
      this.serviceProvidersData = {};
      this.selectedServices.forEach(service => {
        this.serviceProvidersData[service] = this.fb.array([
          this.createServiceProviderGroup(),
        ]);
      });
    });
  }

  get stepOneGroup(): FormGroup {
    return this.lobForm.get('stepOne') as FormGroup;
  }

  get stepTwoGroup(): FormGroup {
    return this.lobForm.get('stepTwo') as FormGroup;
  }

  createServiceProviderGroup(): FormGroup {
    return this.fb.group({
      provider: ['', Validators.required],
      weight: [null, [Validators.required, Validators.min(0), Validators.max(100)]],
    });
  }

  getProvidersArray(service: string): FormArray<FormGroup> {
    return this.serviceProvidersData[service];
  }

  addProvider(service: string) {
    this.getProvidersArray(service).push(this.createServiceProviderGroup());
  }

  removeProvider(service: string, index: number) {
    this.getProvidersArray(service).removeAt(index);
  }

  submit() {
    const payload = {
      ...this.lobForm.value,
      services: {},
    };

    this.selectedServices.forEach(service => {
      payload.services[service] = this.getProvidersArray(service).value;
    });

    console.log('Form Submitted:', payload);
  }
}



