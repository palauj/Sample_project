import { Routes } from '@angular/router';

export const routes: Routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full',
    },

    {
    path: 'login',
    loadComponent: () => import('../auth/login-component/login-component')
    .then( m => m.LoginComponent )
    },

    {
    path: 'dashboard',
    loadComponent: () => import('../app/lob/lob-wizard/lob-wizard')
    .then( m => m. LobWizard)
    },

    {
    path: '**',
    redirectTo: 'login',
  }
];
